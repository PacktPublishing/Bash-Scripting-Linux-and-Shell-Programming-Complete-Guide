#!/bin/bash

# This line prints out the text hello world
echo -n "Hello World"

: 'Line 1
Line 2
Line 3'
echo -e "\n2nd\t Line"