#!/bin/bash

echo -n "Hello World"
echo -e "\n2nd\t Line"