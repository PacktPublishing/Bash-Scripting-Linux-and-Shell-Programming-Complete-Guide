#!/bin/bash

echo $EPIC