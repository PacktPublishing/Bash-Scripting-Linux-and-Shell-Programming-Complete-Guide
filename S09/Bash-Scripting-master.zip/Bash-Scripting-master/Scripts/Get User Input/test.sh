#!/bin/bash

echo "Input your favourite superhero"
read superhero
echo "Your favourite superhero is $superhero"